function imgSwitch(source){
        
    document.getElementById('image-view').innerHTML='<img src="'+source+'"style="width: 100%;" >';
}
